import java.util.Scanner;
class prime
{
     public static void main(String args[])
	 {    
	     Scanner input=new Scanner(System.in);
		  int n, i, count=0;
		 System.out.print("enter the number");
		 n=input.nextInt();
		 for(i=2;i<n/2;i++)
		 {
		     if(n%i==0)
			 {
			     count ++;
             
			 }
		}
		  if(count==0)
		  {
		      System.out.println("number is prime");
		  }
		      else
			  { 
			      System.out.println("number is not prime");
			  }
    }
}	
		 