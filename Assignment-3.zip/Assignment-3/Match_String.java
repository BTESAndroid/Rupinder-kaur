import java.util.Scanner;
class Match_String
{
     public static void main(String arg[])
	 {
		 Scanner input=new Scanner(System.in);
	     System.out.print("enter the String: ");
	     String s=input.nextLine();
	     System.out.print("enter the word that you want to search:");
	     String item=input.nextLine();
	     System.out.print("enter the new word:");
	     String new_item=input.nextLine();
	     String[]s2=s.split(" ");
	     int loc=0,count=0;
	     for(int i=0;i<s2.length;i++)
	     {
	         if(item.equals(s2[1]))
		    {
		         count++;
			     s2[i]=new_item;
		    }
	    }
			   if(count==0)
			    {
				     System.out.println("the word that you entered is not found in string..!!");
			    }
				     else
				     {
					    System.out.print("new String is;");
				        for(int i=0;i<s2.length;i++)
					     {
						    System.out.print(s2[i]+" ");
				        }
				    }
    }
}
			