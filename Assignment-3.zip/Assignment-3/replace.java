//write a programsearch for a word in a string and replace all of its accurances//
public class replace
{
     public static void main(String args[])
	 {
	     String s="i have a book";
		 char s2='o';
		 char s3='j';
		 int loc;
		  
		  char[]arr=s.toCharArray();
		  for(int i=0;i<arr.length;i++)
		{
		     if(s2==arr[i])
			{
			     loc=i;
			     System.out.println("location :"+i);
			     arr[i]=s3;
		    }
		}
			  String sorted = new String(arr);
			  System.out.print("new string is: "+sorted);
	}
}