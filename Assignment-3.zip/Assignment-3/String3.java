/*How to convert numeric String to int in java? */
/*import java.util.Scanner;*/
public class String3
{
     public static void main(String args[])
     {
         String s="123";
         int a= Integer.parseInt(s);
         //Integer s2=Integer.toString(s);
         System.out.println(a);
    }
}