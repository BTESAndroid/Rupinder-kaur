import java.util.Scanner;
class Big_String
{
     public static void main(String args[])
	 {
	      Scanner input=new Scanner(System.in);
		  System.out.print("enter the string:");
		  String s=input.nextLine();
		 String[] s1=s.split(" ");
		  int greatest=s1[0].length();
		  int loc=0;
		  for(int i=0;i<=s1.length-1;i++)
		  {
		      if(s1[i].length()>greatest)
			{
			    greatest=s1[i].length();
				loc=i;
			}
		}
			     System.out.println("biggest substring of string is : "+s1[loc]);
	}

}	