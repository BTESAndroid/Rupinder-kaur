import java.lang.*;
import java.util.Arrays;
public class String2
{
     public static void main(String args[])
	 {
	       String s1="hello";
		   String s2="ehllo";
		   int found=0,not_found=0;
		   s1=s1.toUpperCase();
		   s2=s2.toUpperCase();
		   char[]arr1=s1.toCharArray();
		   char[]arr2=s2.toCharArray();
		   Arrays.sort(arr1);
		   Arrays.sort(arr2);
		   for(int i=0;i<=arr1.length-1;i++)
		   {
		         if(arr1[i]==arr2[i])
				 {
				     found=1;
					 }
					     else
						 {  
						    not_found=1;
                        }
            }	
              if(not_found==1)
              {
            System.out.println("Strings are not anagram..!!");
			  }
			  else
			  {
		    System.out.println("Strings are anagram..!!");
			   }
    }
}
							