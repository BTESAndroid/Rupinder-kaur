import java.util.Scanner;
class fibbo
{
	public static void main(String args[])

	{
		int n1=0, n2=1,fib=0;
		System.out.println("Enter the number till then you want fibbonci series");
		Scanner s=new Scanner(System.in);
		int f=s.nextInt();
		System.out.println(n1+" "+n2);

		for(int i=2;i<f;++i)
		{
			fib=n1+n2;
			System.out.print(" "+fib);
			n1=n2;	
			n2=fib;
		}
	}
}


