import java.util.Arrays;
public class Api
{
     public static void main(String args[])
     {
	     String s="torp";
		 char[]arr=s.toCharArray();
		 Arrays.sort(arr);
		 String sorted = new String(arr);
		 System.out.print("sorted string is:"+sorted);
	}
}