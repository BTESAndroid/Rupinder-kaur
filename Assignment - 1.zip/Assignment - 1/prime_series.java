 public class prime_series
{
     public static void main(String[]args)
	 {
	     boolean flag1;
			 for (int k=1;k<=25;k++)
			 {
			     flag1=true;
				 for (int j=2;j<k;j++)
				 {
				     if (k%j==0)
					 {
					      flag1=false; 
						  break;
					}
			    }
			 
				      if((flag1==true)/*&&(count<i)*/)
					  {
					      System.out.println(k);
						  //count++;
					  }
		 }
			       //System.out.println();
				   //


}}