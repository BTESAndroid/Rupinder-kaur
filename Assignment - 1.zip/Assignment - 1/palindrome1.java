class palindrome1
{
     public static void main(String args[])
      {
         int r,sum=0,temp;
         int n=121;
         temp=n;
         while(n!=0)
         {
             r=n%10;
             sum=r+(sum*10);
              n=n/10;
        }
              if(temp==sum)
               System.out.println(temp+"is a palindrome number");
		   
               else
               System.out.println(temp+" is not a palindrome");
    }
}