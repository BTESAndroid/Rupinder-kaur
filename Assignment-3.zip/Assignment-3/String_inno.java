class String_inno
{
     public static void main(String arg[])
     {
         String s1="hello";
         String s2="bye";
        String s3=s1+s2;
         System.out.println(s3);
    }
}