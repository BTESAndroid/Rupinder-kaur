import java.util.*;
class Rev_String
{
     public static void main(String arg[])
	 {
	 Scanner input=new Scanner(System.in);
	 String s1=input.nextLine();
	 String[]s2=s1.split(" ");
	 System.out.print("first method:");
	 String rev=new StringBuffer(s1).reverse().toString();
	 System.out.print(rev);
	 System.out.print("\nsecond method:");
	 for(int i=s2.length-1;i>=0;i--)
	 {
	     System.out.print(s2[i]+" ");
		 }
		   char[] arr1=s1.toCharArray();
		   System.out.print("\nThird method : ");
		   for(int i=arr1.length-1;i>=0;i--)
		    {
		         System.out.print(arr1[i]);
		    }
	 }
}
				 
	 
